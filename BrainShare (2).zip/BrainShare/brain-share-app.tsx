import { useState } from 'react'
import { Bell, Home, MessageCircle, Search, User, PlusCircle, BarChart, ArrowLeft, Star, ThumbsUp, DollarSign } from 'lucide-react'
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"

import HomePage from './home-page'
import CreateContentPage from './create-content-page'
import ProfilePage from './profile-page'
import NotificationSystem from './notification-system'
import Messaging from './messaging'
import CreatorAnalytics from './creator-analytics'
import SearchPage from './search-page'
import ViewContentPage from './view-content-page'
import ReviewRating from './review-rating'
import RecommendationEngine from './recommendation-engine'
import PurchaseFinancePage from './purchase-finance-page'

const pages = [
  { id: 'home', name: 'Home' },
  { id: 'search', name: 'Search' },
  { id: 'create', name: 'Create Content' },
  { id: 'profile', name: 'Profile' },
  { id: 'notifications', name: 'Notifications' },
  { id: 'messaging', name: 'Messaging' },
  { id: 'analytics', name: 'Analytics' },
  { id: 'reviews', name: 'Reviews' },
  { id: 'recommendations', name: 'Recommended' },
  { id: 'viewContent', name: 'View Content' },
  { id: 'purchase', name: 'Purchase', icon: DollarSign },
]

export default function BrainShareApp() {
  const [currentPage, setCurrentPage] = useState('home')
  const [contentId, setContentId] = useState<string | null>(null)

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage onViewContent={(id) => {
          setContentId(id)
          setCurrentPage('viewContent')
        }} />
      case 'create':
        return <CreateContentPage />
      case 'profile':
        return <ProfilePage />
      case 'notifications':
        return <NotificationSystem />
      case 'messaging':
        return <Messaging />
      case 'analytics':
        return <CreatorAnalytics />
      case 'search':
        return <SearchPage onViewContent={(id) => {
          setContentId(id)
          setCurrentPage('viewContent')
        }} />
      case 'reviews':
        return <ReviewRating />
      case 'recommendations':
        return <RecommendationEngine onViewContent={(id) => {
          setContentId(id)
          setCurrentPage('viewContent')
        }} />
      case 'viewContent':
        return <ViewContentPage contentId={contentId} />
      case 'purchase':
        return <PurchaseFinancePage />
      default:
        return <div>Page not found</div>
    }
  }

  return (
    <div className="flex flex-col h-screen max-w-md mx-auto bg-background text-foreground">
      {/* Header */}
      <header className="flex justify-between items-center p-4 border-b">
        <h1 className="text-2xl font-bold">BrainShare</h1>
        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="icon" onClick={() => setCurrentPage('notifications')}>
            <Bell className="h-6 w-6" />
          </Button>
          <Button variant="ghost" size="icon" onClick={() => setCurrentPage('profile')}>
            <Avatar>
              <AvatarImage src="/placeholder.svg?height=40&width=40" alt="User" />
              <AvatarFallback>U</AvatarFallback>
            </Avatar>
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto">
        {renderPage()}
      </main>

      {/* Footer Navigation */}
      <footer className="flex justify-around items-center p-4 border-t bg-background">
        <Button variant="ghost" size="icon" onClick={() => setCurrentPage('home')}>
          <Home className="h-6 w-6" />
        </Button>
        <Button variant="ghost" size="icon" onClick={() => setCurrentPage('search')}>
          <Search className="h-6 w-6" />
        </Button>
        <Button variant="ghost" size="icon" onClick={() => setCurrentPage('create')}>
          <PlusCircle className="h-6 w-6" />
        </Button>
        <Button variant="ghost" size="icon" onClick={() => setCurrentPage('messaging')}>
          <MessageCircle className="h-6 w-6" />
        </Button>
        <Button variant="ghost" size="icon" onClick={() => setCurrentPage('analytics')}>
          <BarChart className="h-6 w-6" />
        </Button>
      </footer>
    </div>
  )
}


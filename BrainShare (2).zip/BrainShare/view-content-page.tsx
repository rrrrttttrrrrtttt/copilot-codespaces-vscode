import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { MessageCircle, Heart, Share2 } from 'lucide-react'
import SharePopup from './share-popup'
import { useState } from 'react'

interface ViewContentPageProps {
  contentId: string | null
}

export default function ViewContentPage({ contentId }: ViewContentPageProps) {
  const [liked, setLiked] = useState(false);
  const [shareOpen, setShareOpen] = useState(false);
  const content = {
    title: contentId ? `Content ${contentId}` : "Mastering React Hooks: A Comprehensive Guide",
    description: "Learn how to leverage the power of React Hooks in your projects",
    author: {
      name: "Jane Doe",
      role: "Web Development Expert",
      avatar: "/placeholder.svg?height=50&width=50"
    },
    price: 49.99,
    duration: "6 hours",
    difficulty: "Intermediate to Advanced",
    lastUpdated: "July 2023",
    includes: "4 coding exercises, 2 mini-projects"
  }

  return (
    <div className="w-full max-w-2xl mx-auto p-4">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">{content.title}</CardTitle>
          <CardDescription>{content.description}</CardDescription>
          <div className="flex items-center mt-4">
            <Avatar className="h-8 w-8 mr-2">
              <AvatarImage src={content.author.avatar} alt={content.author.name} />
              <AvatarFallback>{content.author.name[0]}</AvatarFallback>
            </Avatar>
            <div>
              <p className="text-sm font-medium">By {content.author.name}</p>
              <p className="text-xs text-muted-foreground">{content.author.role}</p>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <p className="text-lg mb-4">
            Dive deep into the world of React Hooks and take your React skills to the next level. 
            This comprehensive guide covers everything from basic hooks to advanced patterns and best practices.
          </p>
          <h3 className="text-xl font-semibold mb-2">What you'll learn:</h3>
          <ul className="list-disc pl-5 mb-4">
            <li>Understanding the useState and useEffect hooks in depth</li>
            <li>Creating and optimizing custom hooks for reusable logic</li>
            <li>Managing complex state with useReducer</li>
            <li>Optimizing performance with useMemo and useCallback</li>
            <li>Handling side effects with useLayoutEffect</li>
            <li>Best practices and common pitfalls to avoid</li>
          </ul>
          <div className="bg-muted p-4 rounded-md">
            <h4 className="font-semibold mb-2">Course details:</h4>
            <p>Duration: {content.duration}</p>
            <p>Difficulty: {content.difficulty}</p>
            <p>Last updated: {content.lastUpdated}</p>
            <p>Includes: {content.includes}</p>
          </div>
        </CardContent>
        <CardFooter className="flex justify-between items-center">
          <Button>Purchase (${content.price.toFixed(2)})</Button>
          <div className="flex space-x-2">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => setLiked(!liked)}
            >
              <Heart className={`h-5 w-5 ${liked ? 'fill-primary text-primary' : ''}`} />
            </Button>
            <Button variant="ghost" size="icon">
              <MessageCircle className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon" onClick={() => setShareOpen(true)}>
              <Share2 className="h-5 w-5" />
            </Button>
            <SharePopup contentTitle={content.title} open={shareOpen} onOpenChange={setShareOpen} />
          </div>
        </CardFooter>
      </Card>
    </div>
  )
}


import { useState } from 'react'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Heart, MessageCircle } from 'lucide-react'

interface SearchPageProps {
  onViewContent: (id: string) => void
}

export default function SearchPage({ onViewContent }: SearchPageProps) {
  const [searchQuery, setSearchQuery] = useState('')

  return (
    <div className="w-full p-4">
      <Input 
        type="search" 
        placeholder="Search for ideas or topics" 
        className="mb-4"
        value={searchQuery}
        onChange={(e) => setSearchQuery(e.target.value)}
      />
      <Tabs defaultValue="discover" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="discover">Discover</TabsTrigger>
          <TabsTrigger value="recommended">Recommended</TabsTrigger>
        </TabsList>
        <TabsContent value="discover" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Next.js 13 Deep Dive: App Directory and Server Components</CardTitle>
              <CardDescription>Master the latest features of Next.js for optimal performance</CardDescription>
            </CardHeader>
            <CardContent>
              <p>Explore the new app directory structure, learn to leverage server components, and optimize your Next.js applications.</p>
              <div className="flex items-center mt-4 text-sm text-muted-foreground">
                <Avatar className="h-6 w-6 mr-2">
                  <AvatarImage src="/placeholder.svg?height=30&width=30" alt="John Smith" />
                  <AvatarFallback>JS</AvatarFallback>
                </Avatar>
                <span>By John Smith • Frontend Developer</span>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" onClick={() => onViewContent('3')}>View Content ($10)</Button>
              <div className="flex space-x-2">
                <Button variant="ghost" size="icon">
                  <MessageCircle className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon">
                  <Heart className="h-4 w-4" />
                </Button>
              </div>
            </CardFooter>
          </Card>
        </TabsContent>
        <TabsContent value="recommended" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Designing Intuitive User Interfaces: A Comprehensive Guide</CardTitle>
              <CardDescription>Elevate your design skills and create user-friendly interfaces</CardDescription>
            </CardHeader>
            <CardContent>
              <p>Learn the principles of effective UI design, from color theory to layout strategies, and create interfaces that users love.</p>
              <div className="flex items-center mt-4 text-sm text-muted-foreground">
                <Avatar className="h-6 w-6 mr-2">
                  <AvatarImage src="/placeholder.svg?height=30&width=30" alt="Emily Johnson" />
                  <AvatarFallback>EJ</AvatarFallback>
                </Avatar>
                <span>By Emily Johnson • UX/UI Designer</span>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" onClick={() => onViewContent('4')}>View Content ($15)</Button>
              <div className="flex space-x-2">
                <Button variant="ghost" size="icon">
                  <MessageCircle className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon">
                  <Heart className="h-4 w-4" />
                </Button>
              </div>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}


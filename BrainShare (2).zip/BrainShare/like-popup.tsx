import { useState } from 'react'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Heart } from 'lucide-react'

export default function LikePopup({ contentTitle }: { contentTitle: string }) {
  const [liked, setLiked] = useState(false)

  const handleLike = () => {
    setLiked(!liked)
  }

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline" size="icon">
          <Heart className={`h-4 w-4 ${liked ? 'fill-primary' : ''}`} />
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{liked ? 'Content Liked!' : 'Like this content?'}</DialogTitle>
          <DialogDescription>
            {liked 
              ? `You've liked "${contentTitle}". It will be added to your favorites.` 
              : `Do you want to like "${contentTitle}"?`}
          </DialogDescription>
        </DialogHeader>
        <div className="flex justify-center mt-4">
          <Button onClick={handleLike} className="px-8">
            {liked ? 'Unlike' : 'Like'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}


import { useState } from 'react'
import { Send } from 'lucide-react'
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"

interface Message {
  id: number;
  sender: string;
  content: string;
  timestamp: string;
}

export default function Messaging() {
  const [messages, setMessages] = useState<Message[]>([
    { id: 1, sender: 'Jane Doe', content: 'Hi there! I saw your React Hooks tutorial and I have a question.', timestamp: '10:30 AM' },
    { id: 2, sender: 'You', content: 'Hello! Sure, what would you like to know?', timestamp: '10:32 AM' },
    { id: 3, sender: 'Jane Doe', content: 'I\'m having trouble understanding useCallback. Could you explain it a bit more?', timestamp: '10:35 AM' },
  ]);
  const [newMessage, setNewMessage] = useState('');

  const handleSendMessage = () => {
    if (newMessage.trim()) {
      setMessages([...messages, {
        id: messages.length + 1,
        sender: 'You',
        content: newMessage.trim(),
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }]);
      setNewMessage('');
    }
  };

  return (
    <div className="flex flex-col h-screen max-w-md mx-auto bg-background text-foreground">
      <header className="flex items-center p-4 border-b">
        <Avatar className="w-10 h-10 mr-3">
          <AvatarImage src="/placeholder.svg?height=40&width=40" alt="Jane Doe" />
          <AvatarFallback>JD</AvatarFallback>
        </Avatar>
        <div>
          <h2 className="font-semibold">Jane Doe</h2>
          <p className="text-sm text-muted-foreground">Web Development Expert</p>
        </div>
      </header>

      <ScrollArea className="flex-1 p-4">
        {messages.map((message) => (
          <Card key={message.id} className={`mb-4 ${message.sender === 'You' ? 'ml-auto' : 'mr-auto'}`} style={{maxWidth: '80%'}}>
            <CardHeader className="p-3">
              <CardTitle className="text-sm font-semibold">{message.sender}</CardTitle>
            </CardHeader>
            <CardContent className="p-3 pt-0">
              <p className="text-sm">{message.content}</p>
              <p className="text-xs text-muted-foreground mt-1">{message.timestamp}</p>
            </CardContent>
          </Card>
        ))}
      </ScrollArea>

      <div className="p-4 border-t">
        <div className="flex items-center">
          <Input
            type="text"
            placeholder="Type a message..."
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            className="flex-1 mr-2"
          />
          <Button onClick={handleSendMessage} size="icon">
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  )
}


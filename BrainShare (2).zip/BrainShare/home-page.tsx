import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Heart, MessageCircle } from 'lucide-react'

interface HomePageProps {
  onViewContent: (id: string) => void
}

export default function HomePage({ onViewContent }: HomePageProps) {
  return (
    <div className="w-full p-4">
      <Tabs defaultValue="followed" className="w-full">
        <TabsList className="grid w-full grid-cols-1 mb-4">
          <TabsTrigger value="followed">Followed</TabsTrigger>
        </TabsList>
        <TabsContent value="followed" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Mastering React Hooks: A Comprehensive Guide</CardTitle>
              <CardDescription>Learn how to leverage the power of React Hooks in your projects</CardDescription>
            </CardHeader>
            <CardContent>
              <p>Dive deep into useState, useEffect, and custom hooks. Perfect for intermediate React developers looking to level up their skills.</p>
              <div className="flex items-center mt-4 text-sm text-muted-foreground">
                <Avatar className="h-6 w-6 mr-2">
                  <AvatarImage src="/placeholder.svg?height=30&width=30" alt="Jane Doe" />
                  <AvatarFallback>JD</AvatarFallback>
                </Avatar>
                <span>By Jane Doe • Web Development Expert</span>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" onClick={() => onViewContent('1')}>View Content ($5)</Button>
              <div className="flex space-x-2">
                <Button variant="ghost" size="icon">
                  <MessageCircle className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon">
                  <Heart className="h-4 w-4" />
                </Button>
              </div>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Building Scalable APIs with GraphQL</CardTitle>
              <CardDescription>Optimize your backend for complex data requirements</CardDescription>
            </CardHeader>
            <CardContent>
              <p>Learn how to design and implement efficient GraphQL schemas, resolvers, and integrations with various databases.</p>
              <div className="flex items-center mt-4 text-sm text-muted-foreground">
                <Avatar className="h-6 w-6 mr-2">
                  <AvatarImage src="/placeholder.svg?height=30&width=30" alt="Alex Johnson" />
                  <AvatarFallback>AJ</AvatarFallback>
                </Avatar>
                <span>By Alex Johnson • Backend Developer</span>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" onClick={() => onViewContent('2')}>View Content ($8)</Button>
              <div className="flex space-x-2">
                <Button variant="ghost" size="icon">
                  <MessageCircle className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="icon">
                  <Heart className="h-4 w-4" />
                </Button>
              </div>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}


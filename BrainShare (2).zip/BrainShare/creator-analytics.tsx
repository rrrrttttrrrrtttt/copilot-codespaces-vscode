import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

const data = [
  { name: 'Mon', views: 400, earnings: 240 },
  { name: 'Tue', views: 300, earnings: 139 },
  { name: 'Wed', views: 200, earnings: 980 },
  { name: 'Thu', views: 278, earnings: 390 },
  { name: 'Fri', views: 189, earnings: 480 },
  { name: 'Sat', views: 239, earnings: 380 },
  { name: 'Sun', views: 349, earnings: 430 },
];

export default function CreatorAnalytics() {
  return (
    <div className="max-w-4xl mx-auto p-4 bg-background text-foreground">
      <h1 className="text-3xl font-bold mb-6">Creator Analytics</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Views</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1,955</div>
            <p className="text-xs text-muted-foreground">+20.1% from last week</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Earnings</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">$3,039</div>
            <p className="text-xs text-muted-foreground">+15% from last month</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg. Rating</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">4.8</div>
            <p className="text-xs text-muted-foreground">Based on 56 reviews</p>
          </CardContent>
        </Card>
      </div>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Weekly Performance</CardTitle>
          <CardDescription>Your content views and earnings for the past week</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={data}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis yAxisId="left" orientation="left" stroke="#8884d8" />
              <YAxis yAxisId="right" orientation="right" stroke="#82ca9d" />
              <Tooltip />
              <Bar yAxisId="left" dataKey="views" fill="#8884d8" name="Views" />
              <Bar yAxisId="right" dataKey="earnings" fill="#82ca9d" name="Earnings ($)" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Top Performing Content</CardTitle>
          <CardDescription>Your most viewed and highest earning content</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <div>
                <p className="font-medium">React Hooks Masterclass</p>
                <p className="text-sm text-muted-foreground">Published on June 1, 2023</p>
              </div>
              <div className="text-right">
                <p className="font-medium">1,245 views</p>
                <p className="text-sm text-muted-foreground">$623 earned</p>
              </div>
            </div>
            <div className="flex justify-between items-center">
              <div>
                <p className="font-medium">Advanced State Management</p>
                <p className="text-sm text-muted-foreground">Published on May 15, 2023</p>
              </div>
              <div className="text-right">
                <p className="font-medium">987 views</p>
                <p className="text-sm text-muted-foreground">$494 earned</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}


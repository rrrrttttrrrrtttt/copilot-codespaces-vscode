import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function CreateContentPage() {
  return (
    <div className="p-4">
      <h2 className="text-2xl font-bold mb-4">Create Content</h2>
      <form className="space-y-4">
        <div>
          <Label htmlFor="title">Title</Label>
          <Input id="title" placeholder="Enter your content title" />
        </div>
        <div>
          <Label htmlFor="description">Description</Label>
          <Textarea id="description" placeholder="Provide a brief description of your content" />
        </div>
        <div>
          <Label htmlFor="category">Category</Label>
          <Select>
            <SelectTrigger id="category">
              <SelectValue placeholder="Select a category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="webdev">Web Development</SelectItem>
              <SelectItem value="mobile">Mobile Development</SelectItem>
              <SelectItem value="design">Design</SelectItem>
              <SelectItem value="business">Business</SelectItem>
              <SelectItem value="marketing">Marketing</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label htmlFor="price">Price ($)</Label>
          <Input id="price" type="number" min="0" step="0.01" placeholder="Set your content price" />
        </div>
        <div>
          <Label htmlFor="content">Content</Label>
          <Textarea id="content" placeholder="Write your content here or provide a link to your content" rows={6} />
        </div>
        <Button type="submit" className="w-full">Publish Content</Button>
      </form>
    </div>
  )
}

